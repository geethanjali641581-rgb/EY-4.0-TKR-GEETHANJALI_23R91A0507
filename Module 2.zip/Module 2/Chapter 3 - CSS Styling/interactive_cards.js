// Simple JavaScript interaction for card buttons
function showMessage(cardName) {
    alert("You clicked on " + cardName);
}